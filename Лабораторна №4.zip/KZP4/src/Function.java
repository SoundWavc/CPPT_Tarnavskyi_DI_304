/**
 * Class <code>Functions</code> implements method for sin(x-9)/(x-cos(2x)) expression
 * calculation
 * @version 1.0
 */

public class Function {
    /**
    * Method calculates the sin(x-9)/(x-cos(2x)) expression*
    * @param x Angle in degrees
    * @throw CalcException
    * @return result
    */
    public static double calculate(double x) throws CalcException {
        double y;
        double rad = x * Math.PI / 180.0;

        try {
            y = Math.sin(rad-9) / (rad - Math.cos(2*rad));

            // Якщо результат не є числом, то генеруємо виключення
            if (Double.isNaN(y) || y == Double.NEGATIVE_INFINITY || y == Double.POSITIVE_INFINITY)
                throw new ArithmeticException();
        }
        // створимо виключення вищого рівня з поясненням причини
        // виникнення помилки
        catch (ArithmeticException ex) {
            System.out.println(ex.getMessage());
            throw new CalcException();
        }

        return y;
    }
}
