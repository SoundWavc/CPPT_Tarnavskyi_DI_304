package KI.Tarnavskyi.Lab2;

import java.io.IOException;
import java.util.List;
import java.util.Random;

/**
 * Клас AlpinistEquipment представляє спорядження альпініста та містить методи для управління ним.
 */
public class AlpinistEquipment {
    private Backpack backpack;
    private Rope rope;
    private Helmet helmet;
    private Logger logger;
    private List<String> equipment;

    /**
     * Конструктор для створення об'єкта спорядження альпініста з базовими компонентами.
     *
     * @param equipment початковий список спорядження
     * @throws IOException якщо виникають помилки під час ініціалізації логера
     */
    public AlpinistEquipment(List<String> equipment) throws IOException {
        this.equipment = equipment;
        this.backpack = new Backpack();
        this.rope = new Rope();
        this.helmet = new Helmet();

        this.logger = new Logger("alpinist_equipment_log.txt");
        logger.log(String.format("Спорядження альпініста %s створена.", this.toString()));
    }

    /**
     * Конструктор з параметрами для налаштування спорядження альпініста.
     *
     * @param backpack об'єкт рюкзака
     * @param rope об'єкт мотузки
     * @param helmet об'єкт шолома
     * @param equipment початковий список спорядження
     * @throws IOException якщо виникають помилки під час ініціалізації логера
     */
    public AlpinistEquipment(Backpack backpack, Rope rope, Helmet helmet, List<String> equipment) throws IOException {
        this.backpack = backpack;
        this.rope = rope;
        this.helmet = helmet;
        this.equipment = equipment;

        this.logger = new Logger("alpinist_equipment_log.txt");
        logger.log(String.format("Спорядження альпініста %s створена.", this.toString()));
    }

    /**
     * Додає предмет спорядження до списку.
     *
     * @param item назва спорядження
     * @throws IOException якщо виникають помилки при записі в лог
     */
    public void addEquipment(String item) throws IOException {
        equipment.add(item);
        logger.log(String.format("Добавлено спорядження %s", item));
        System.out.printf("Добавлено спорядження %s\n", item);
    }

    /**
     * Видаляє предмет спорядження зі списку.
     *
     * @param item назва спорядження
     * @throws IOException якщо виникають помилки при записі в лог
     */
    public void removeEquipment(String item) throws IOException {
        equipment.remove(item);
        logger.log(String.format("Видалено спорядження %s", item));
        System.out.printf("Видалено спорядження %s\n", item);
    }

    /**
     * Повертає список всього спорядження.
     *
     * @return список спорядження
     * @throws IOException якщо виникають помилки при записі в лог
     */
    public List<String> getEquipmentList() throws IOException {
        logger.log(String.format("Показати спорядження %s", equipment));
        System.out.printf("Показати спорядження %s\n", equipment);
        return equipment;
    }

    /**
     * Змінює місткість рюкзака.
     *
     * @param capacity нова місткість
     * @throws IOException якщо виникають помилки при записі в лог
     */
    public void changeBackpackCapacity(int capacity) throws IOException {
        backpack.setCapacity(capacity);
        logger.log(String.format("Змінити місткість рюкзака %s", capacity));
        System.out.printf("Змінити місткість рюкзака %s\n", capacity);
    }

    /**
     * Змінює довжину мотузки.
     *
     * @param length нова довжина
     * @throws IOException якщо виникають помилки при записі в лог
     */
    public void changeRopeLength(int length) throws IOException {
        rope.setLength(length);
        logger.log(String.format("Змінити довжину мотузки %s", length));
        System.out.printf("Змінити довжину мотузки %s\n", length);
    }

    /**
     * Перевіряє, чи є певний предмет спорядження в списку.
     *
     * @param item назва спорядження
     * @return true, якщо спорядження є в списку, інакше false
     * @throws IOException якщо виникають помилки при записі в лог
     */
    public boolean hasEquipment(String item) throws IOException {
        boolean result = equipment.contains(item);
        logger.log(String.format("Перевірка на наявність предмету: %s. Результат: %s", item, result));
        System.out.printf("Перевірка на наявність предмету: %s. Результат: %s\n", item, result);
        return result;
    }

    /**
     * Повертає загальну вагу спорядження.
     *
     * @return загальна вага спорядження
     * @throws IOException якщо виникають помилки при записі в лог
     */
    public double getTotalWeight() throws IOException {
        double totalWeight = backpack.getWeight() + rope.getWeight() + helmet.getWeight();
        logger.log(String.format("Загальна вага спорядження: %s", totalWeight));
        System.out.printf("Загальна вага спорядження: %s\n", totalWeight);
        return totalWeight;
    }

    /**
     * Перевіряє, чи готове спорядження до експедиції.
     *
     * @return true, якщо спорядження готове, інакше false
     * @throws IOException якщо виникають помилки при записі в лог
     */
    public boolean isReadyForExpedition() throws IOException {
        boolean isReady = equipment.size() >= 5 && hasEquipment("Crampon") && hasEquipment("Ice axe");
        logger.log(String.format("Перевірка спорядження до експедиції. Результат: %s", isReady));
        System.out.printf("Перевірка спорядження до експедиції. Результат: %s\n", isReady);
        return isReady;
    }

    /**
     * Симулює випадкове пошкодження спорядження під час експедиції.
     *
     * @return назва пошкодженого предмету або null, якщо пошкодження не сталося
     * @throws IOException якщо виникають помилки при записі в лог
     */
    public String simulateRandomDamage() throws IOException {
        if (equipment.isEmpty()) {
            logger.log("Спроба симуляції пошкодження: спорядження порожнє");
            System.out.println("Спорядження порожнє, нема чого пошкоджувати!");
            return null;
        }

        Random random = new Random();
        if (random.nextInt(10) < 3) {
            int index = random.nextInt(equipment.size());
            String damagedItem = equipment.get(index);
            logger.log(String.format("Симуляція пошкодження: пошкоджено предмет '%s'", damagedItem));
            System.out.printf("Ох ні! Предмет '%s' був пошкоджений під час експедиції!\n", damagedItem);
            return damagedItem;
        } else {
            logger.log("Симуляція пошкодження: пошкодження не сталося");
            System.out.println("На щастя, все спорядження залишилося цілим під час цієї експедиції.");
            return null;
        }
    }

    /**
     * Розраховує максимальну висоту, на яку можна піднятися з поточним спорядженням.
     *
     * @return максимальна висота в метрах
     * @throws IOException якщо виникають помилки при записі в лог
     */
    public int calculateMaxClimbingHeight() throws IOException {
        int baseHeight = 1000;
        int additionalHeight = 0;

        for (String item : equipment) {
            switch (item.toLowerCase()) {
                case "crampon":
                    additionalHeight += 500;
                    break;
                case "ice axe":
                    additionalHeight += 300;
                    break;
                case "oxygen tank":
                    additionalHeight += 1000;
                    break;
                default:
                    additionalHeight += 50;
            }
        }

        int maxHeight = baseHeight + additionalHeight;
        logger.log(String.format("Розрахунок максимальної висоти підйому: %d метрів", maxHeight));
        System.out.printf("З поточним спорядженням ви можете піднятися на висоту до %d метрів!\n", maxHeight);
        return maxHeight;
    }

    /**
     * Закриває логер для збереження даних у файл.
     *
     * @throws IOException якщо виникає помилка під час закриття логера
     */
    public void closeLogger() throws IOException {
        logger.close();
    }
}
