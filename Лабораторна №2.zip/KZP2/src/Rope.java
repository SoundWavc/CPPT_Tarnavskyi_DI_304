package KI.Tarnavskyi.Lab2;

/**
 * Клас Rope представляє мотузку альпініста з довжиною та вагою.
 */
public class Rope {
    private int length; // Довжина мотузки в метрах
    private double weight; // Вага мотузки в кілограмах

    /**
     * Конструктор без параметрів, створює мотузку довжиною 50 метрів та вагою 3.5 кг.
     */
    public Rope() {
        this.length = 50;
        this.weight = 3.5;
    }

    /**
     * Конструктор, який дозволяє встановити довжину мотузки.
     *
     * @param length довжина мотузки в метрах
     */
    public Rope(int length) {
        this.length = length;
        this.weight = length * 0.07;
    }

    /**
     * Встановлює нову довжину мотузки і автоматично обчислює вагу.
     *
     * @param length нова довжина мотузки в метрах
     */
    public void setLength(int length) {
        this.length = length;
        this.weight = length * 0.07;
    }

    /**
     * Повертає вагу мотузки.
     *
     * @return вага мотузки в кілограмах
     */
    public double getWeight() {
        return weight;
    }

    /**
     * Повертає довжину мотузки.
     *
     * @return довжина мотузки в метрах
     */
    public int getLength() {
        return length;
    }
}