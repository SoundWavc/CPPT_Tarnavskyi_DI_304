package KI.Tarnavskyi.Lab2;

/**
 * Клас Helmet представляє каску альпініста з розміром і вагою.
 */
public class Helmet {
    private String size; // Розмір каски
    private double weight; // Вага каски в кілограмах

    /**
     * Конструктор без параметрів, створює каску з розміром M і вагою 0.3 кг.
     */
    public Helmet() {
        this.size = "M";
        this.weight = 0.3;
    }

    /**
     * Конструктор, який дозволяє встановити розмір каски.
     *
     * @param size розмір каски
     */
    public Helmet(String size) {
        this.size = size;
        this.weight = 0.3;
    }

    /**
     * Встановлює новий розмір каски.
     *
     * @param size новий розмір каски
     */
    public void setSize(String size) {
        this.size = size;
    }

    /**
     * Повертає вагу каски.
     *
     * @return вага каски в кілограмах
     */
    public double getWeight() {
        return weight;
    }

    /**
     * Повертає розмір каски.
     *
     * @return розмір каски
     */
    public String getSize() {
        return size;
    }
}
