package KI.Tarnavskyi.Lab2;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Клас AlpinistEquipmentDriver демонструє роботу з класом AlpinistEquipment.
 */
public class AlpinistEquipmentDriver {
    /**
     * Головний метод.
     *
     * @param args аргументи командного рядка (не використовуються).
     */
    public static void main(String[] args) {
        List<String> equipment = new ArrayList<>();
        equipment.add("Пояс страхувальний");
        equipment.add("Зажиим");
        equipment.add("Пояси");


        try {
            AlpinistEquipment alpinistEquipment = new AlpinistEquipment(equipment);
            alpinistEquipment.addEquipment("Рукавиці");
            alpinistEquipment.removeEquipment("Зажим");
            alpinistEquipment.getEquipmentList();
            alpinistEquipment.changeBackpackCapacity(10);
            alpinistEquipment.changeRopeLength(100);
            alpinistEquipment.hasEquipment("Зажим");
            alpinistEquipment.getTotalWeight();
            alpinistEquipment.isReadyForExpedition();
            alpinistEquipment.simulateRandomDamage();
            alpinistEquipment.calculateMaxClimbingHeight();

            alpinistEquipment.closeLogger();
        } catch (IOException e) {
            // Обробка помилок, що виникають під час запису в файл
            throw new RuntimeException("Сталася помилка при записі в файл: " + e.getMessage());
        }
    }
}
