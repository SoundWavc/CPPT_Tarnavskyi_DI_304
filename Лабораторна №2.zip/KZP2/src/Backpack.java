package KI.Tarnavskyi.Lab2;

/**
 * Клас Backpack представляє рюкзак альпініста з місткістю і вагою.
 */
public class Backpack {
    private int capacity; // Місткість рюкзака в літрах
    private double weight; // Вага рюкзака в кілограмах

    /**
     * Конструктор без параметрів, створює рюкзак з місткістю 50 літрів і вагою 2.0 кг.
     */
    public Backpack() {
        this.capacity = 50;
        this.weight = 2.0;
    }

    /**
     * Конструктор, який дозволяє встановити місткість рюкзака.
     *
     * @param capacity місткість рюкзака в літрах
     */
    public Backpack(int capacity) {
        this.capacity = capacity;
        this.weight = 2.0;
    }

    /**
     * Встановлює нову місткість рюкзака.
     *
     * @param capacity нова місткість рюкзака в літрах
     */
    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    /**
     * Повертає вагу рюкзака.
     *
     * @return вага рюкзака в кілограмах
     */
    public double getWeight() {
        return weight;
    }

    /**
     * Повертає місткість рюкзака.
     *
     * @return місткість рюкзака в літрах
     */
    public int getCapacity() {
        return capacity;
    }
}
