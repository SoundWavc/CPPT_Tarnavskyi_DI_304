package KI.Tarnavskyi.Lab3;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Клас MilitaryAlpinistEquipmentDriver демонструє роботу з класом MilitaryAlpinistEquipment.
 */
public class MilitaryAlpinistEquipmentDriver {
    /**
     * Головний метод.
     *
     * @param args аргументи командного рядка (не використовуються).
     */
    public static void main(String[] args) {
        List<String> militaryEquipment = new ArrayList<>();
        militaryEquipment.add("чоботи-кішки");
        militaryEquipment.add("Сокира для льоду");
        militaryEquipment.add("Окуляри нічного бачення");
        militaryEquipment.add("зброя");

        try {
            MilitaryAlpinistEquipment militaryAlpinist = new MilitaryAlpinistEquipment(militaryEquipment, true, 5);

            militaryAlpinist.addEquipment("Аптечка");
            militaryAlpinist.removeEquipment("Сокира для льоду");
            militaryAlpinist.getEquipmentList();
            militaryAlpinist.changeBackpackCapacity(20);
            militaryAlpinist.changeRopeLength(150);
            militaryAlpinist.hasEquipment("Окуляри нічного бачення");
            militaryAlpinist.getTotalWeight();
            militaryAlpinist.isReadyForExpedition();
            militaryAlpinist.simulateRandomDamage();
            militaryAlpinist.calculateMaxClimbingHeight();

            System.out.println("Рівень підготовки до бою: " + militaryAlpinist.evaluateCombatReadiness());
            System.out.println("Має зброю: " + militaryAlpinist.hasWeapon());
            System.out.println("Рівень захисту: " + militaryAlpinist.getProtectionLevel());

            militaryAlpinist.closeLogger();
        } catch (IOException e) {
            throw new RuntimeException("Сталася помилка при записі в файл: " + e.getMessage());
        }
    }
}
