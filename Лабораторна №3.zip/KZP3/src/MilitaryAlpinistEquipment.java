package KI.Tarnavskyi.Lab3;

import java.io.IOException;
import java.util.List;

/**
 * Інтерфейс MilitaryEquipment описує додаткові вимоги до військового спорядження.
 */
interface MilitaryEquipment {
    /**
     * Метод для перевірки наявності військової зброї.
     *
     * @return true, якщо зброя присутня, інакше false.
     */
    boolean hasWeapon();

    /**
     * Метод для визначення рівня захисту спорядження.
     *
     * @return рівень захисту.
     */
    int getProtectionLevel();

    /**
     * Оцінює рівень боєздатності спорядження.
     *
     * @return рівень боєздатності (від 0 до 100)
     */
    int evaluateCombatReadiness();
}

/**
 * Клас MilitaryAlpinistEquipment представляє спорядження військового альпініста та містить додаткові функції.
 */
public class MilitaryAlpinistEquipment extends AlpinistEquipment implements MilitaryEquipment {
    private boolean hasWeapon;
    private int protectionLevel;

    /**
     * Конструктор для створення військового спорядження з базовими компонентами.
     *
     * @param equipment початковий список спорядження.
     * @param hasWeapon наявність зброї.
     * @param protectionLevel рівень захисту.
     * @throws IOException якщо виникають помилки під час ініціалізації логера.
     */
    public MilitaryAlpinistEquipment(List<String> equipment, boolean hasWeapon, int protectionLevel) throws IOException {
        super(equipment);
        this.hasWeapon = hasWeapon;
        this.protectionLevel = protectionLevel;
    }

    /**
     * Реалізація методу для перевірки наявності зброї.
     *
     * @return true, якщо зброя присутня.
     */
    @Override
    public boolean hasWeapon() {
        return hasWeapon;
    }

    /**
     * Реалізація методу для визначення рівня захисту спорядження.
     *
     * @return рівень захисту.
     */
    @Override
    public int getProtectionLevel() {
        return protectionLevel;
    }


    /**
     * Реалізація методу для оцінки боєздатності спорядження.
     *
     * @return рівень боєздатності (від 0 до 100)
     * @throws IOException якщо виникають помилки при записі в лог
     */
    @Override
    public int evaluateCombatReadiness() {
        int readiness = 0;

        for (String item : equipment) {
            switch (item.toLowerCase()) {
                case "зброя":
                    readiness += 40;
                    break;
                case "бронежилет":
                    readiness += 30;
                    break;
                case "каска":
                    readiness += 20;
                    break;
                case "медичний набір":
                    readiness += 10;
                    break;
            }
        }

        try {
            logger.log(String.format("Рівень боєздатності спорядження: %d", readiness));
        } catch (IOException e) {
            System.out.println("Помилка запису в лог: " + e.getMessage());
        }

        return readiness;
    }
}