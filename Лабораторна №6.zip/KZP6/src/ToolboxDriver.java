package KI.Tarnavskyi.Lab6;

/**
 * Клас для тестування параметризованої коробки для інструментів.
 */
public class ToolboxDriver {

    public static void main(String[] args) {
        Toolbox<Integer> numberBox = new Toolbox<>();
        Toolbox<String> stringBox = new Toolbox<>();

        // Додавання чисел до коробки
        numberBox.addItem(10);
        numberBox.addItem(25);
        numberBox.addItem(3);
        numberBox.addItem(17);

        // Додавання рядків до коробки
        stringBox.addItem("Hammer");
        stringBox.addItem("Screwdriver");
        stringBox.addItem("Wrench");

        // Пошук мінімального елемента у коробці чисел
        System.out.println("Мінімальне число: " + numberBox.findMinItem());

        // Перевірка наявності елемента в коробці рядків
        System.out.println("Чи є 'Screwdriver' у коробці? " + stringBox.containsItem("Screwdriver"));

        // Очищення коробки з рядками
        stringBox.clear();
        System.out.println("Кількість елементів у коробці після очищення: " + stringBox.getItemCount());

        numberBox.addItem(12);

        System.out.println("Оновлений список чисел: ");
        System.out.println(numberBox);
    }
}
